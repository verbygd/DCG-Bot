import { motion, useScroll, useTransform } from "framer-motion";
import { 
  Bot, 
  Terminal, 
  Gamepad2, 
  Coins, 
  Swords, 
  Zap, 
  Wrench, 
  Sparkles,
  ArrowRight,
  Code2,
  Cpu,
  Trophy,
  Users,
  ShieldAlert,
  Smile,
  Hash,
  Star,
  Activity,
  MessageSquare
} from "lucide-react";
import { SiDiscord, SiPython } from "react-icons/si";
import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const INVITE_URL = "https://discord.com/oauth2/authorize?client_id=1471426379634573494&permissions=4503599627488256&integration_type=0&scope=bot+applications.commands";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const commands = [
  "guessnumber", "guess", "8ball", "wouldyourather", "coinflip", "burgerflip", "ship", "luck", "rng", "hottake", "who", "braincellcount",
  "biscuits", "daily", "shop", "openbox", "work", "crime", "steal", "leaderboard", "stats", "grab", "buy", "give",
  "help", "ping", "serverinfo", "botinfo", "roleinfo", "afk", "countdown", "password", "reverse", "randomnumber", "randomcolor", "palette", "topemoji", "say", "fixnames",
  "catfact", "cozyfact", "islamfact", "randomfact", "dog", "mock", "quote", "addquote", "bnuuy", "idk", "gayrate", "simprate", "furryrate", "stupidityrate", "femboyrate",
  "biscuitsadmin", "spawnboss", "attack", "complexmath", "simplemath", "pick"
];

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  
  // Marquee effect
  const [marqueePosition, setMarqueePosition] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setMarqueePosition(prev => {
        // Reset when it scrolls far enough
        if (prev <= -2000) return 0;
        return prev - 1;
      });
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <div ref={containerRef} className="min-h-screen bg-background text-foreground overflow-hidden font-sans relative selection:bg-primary/30 selection:text-primary-foreground">
      {/* Noise Overlay */}
      <div className="fixed inset-0 pointer-events-none z-50 opacity-[0.03] mix-blend-overlay" 
           style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}>
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-background/50 backdrop-blur-xl border-b border-white/5">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30 box-glow group transition-all hover:bg-primary/30">
              <Bot className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
            </div>
            <span className="font-sans font-bold text-2xl tracking-tighter text-glow text-white">DCG Bot</span>
          </div>
          <a href={INVITE_URL} target="_blank" rel="noopener noreferrer" data-testid="nav-invite-btn">
            <Button 
              className="rounded-full px-6 font-bold bg-primary hover:bg-primary/90 text-white shadow-[0_0_20px_hsl(var(--primary)/0.4)] transition-all hover:scale-105 hover:shadow-[0_0_30px_hsl(var(--primary)/0.6)]"
            >
              <SiDiscord className="w-5 h-5 mr-2" />
              Add to Discord
            </Button>
          </a>
        </div>
      </nav>

      {/* 1. Hero Section */}
      <section className="relative min-h-[100dvh] flex items-center pt-20">
        <motion.div 
          className="absolute inset-0 z-0"
          style={{ y: backgroundY }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background z-10" />
          <img 
            src="/hero-bg.png" 
            alt="Abstract Neon Waves" 
            className="w-full h-full object-cover object-center opacity-40 mix-blend-screen"
          />
        </motion.div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              className="max-w-2xl"
            >
              <motion.div variants={fadeIn} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/20 text-secondary mb-8 font-mono text-sm shadow-[0_0_20px_hsl(var(--secondary)/0.2)]">
                <Sparkles className="w-4 h-4" />
                <span>The ultimate multipurpose companion</span>
              </motion.div>
              
              <motion.h1 variants={fadeIn} className="text-5xl md:text-7xl lg:text-8xl font-black leading-[1.1] mb-6 tracking-tighter text-white">
                Born from <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Boredom.</span><br />
                Built for <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-accent">Communities.</span>
              </motion.h1>
              
              <motion.p variants={fadeIn} className="text-xl md:text-2xl text-muted-foreground mb-10 leading-relaxed max-w-xl font-light">
                What started as a solo dev's weekend experiment is now a powerhouse of economy, games, utility, and absolute chaos. Meet your server's new best friend.
              </motion.p>
              
              <motion.div variants={fadeIn} className="flex flex-wrap gap-4">
                <a href={INVITE_URL} target="_blank" rel="noopener noreferrer" data-testid="hero-invite-btn">
                  <Button 
                    size="lg" 
                    className="rounded-full px-8 h-14 text-lg font-bold bg-primary hover:bg-primary/90 text-white shadow-[0_0_30px_hsl(var(--primary)/0.3)] hover:shadow-[0_0_40px_hsl(var(--primary)/0.5)] transition-all hover:-translate-y-1"
                  >
                    <SiDiscord className="w-6 h-6 mr-3" />
                    Invite DCG Bot
                  </Button>
                </a>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="rounded-full px-8 h-14 text-lg font-bold border-white/10 bg-white/5 hover:bg-white/10 backdrop-blur-md transition-all text-white hover:text-primary group"
                  data-testid="hero-commands-btn"
                  onClick={() => document.getElementById('commands-marquee')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <Terminal className="w-5 h-5 mr-3 text-muted-foreground group-hover:text-primary transition-colors" />
                  View Commands
                </Button>
              </motion.div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, type: "spring", bounce: 0.4 }}
              className="relative hidden lg:block"
            >
              <div className="absolute inset-0 bg-primary/20 blur-[120px] rounded-full mix-blend-screen" />
              <div className="absolute inset-20 bg-secondary/20 blur-[80px] rounded-full mix-blend-screen" />
              <img 
                src="/bot-mascot.png" 
                alt="DCG Bot Mascot" 
                className="w-full max-w-lg mx-auto relative z-10 drop-shadow-[0_0_30px_hsl(var(--primary)/0.5)] animate-in slide-in-from-bottom-8 duration-1000"
                style={{ animation: 'float 6s ease-in-out infinite' }}
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* 2. Marquee Commands */}
      <div id="commands-marquee" className="py-6 border-y border-white/5 bg-background/50 backdrop-blur-sm overflow-hidden flex relative z-10">
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-background to-transparent z-20 pointer-events-none" />
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-background to-transparent z-20 pointer-events-none" />
        
        <motion.div 
          className="flex gap-4 whitespace-nowrap"
          style={{ x: marqueePosition }}
        >
          {[...commands, ...commands, ...commands, ...commands, ...commands].map((cmd, i) => (
            <div key={i} className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-muted-foreground font-mono text-sm font-medium hover:text-white transition-colors hover:bg-white/10 cursor-default group">
              <span className="text-primary/50 group-hover:text-primary transition-colors">/</span>
              {cmd}
            </div>
          ))}
        </motion.div>
      </div>

      {/* 3. The Story Section */}
      <section className="py-32 relative bg-background border-b border-white/5 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.02]" />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/5 blur-[150px] rounded-full pointer-events-none" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="max-w-4xl mx-auto text-center"
          >
            <motion.div variants={fadeIn} className="w-20 h-20 mx-auto bg-accent/10 border border-accent/20 rounded-3xl flex items-center justify-center mb-8 box-glow-accent rotate-3 hover:rotate-0 transition-transform cursor-default">
              <SiPython className="w-10 h-10 text-accent" />
            </motion.div>
            <motion.h2 variants={fadeIn} className="text-4xl md:text-6xl font-black mb-8 text-glow text-white">A Passion Project Gone Wild</motion.h2>
            <motion.p variants={fadeIn} className="text-xl md:text-3xl text-muted-foreground leading-relaxed font-light">
              Built with Python and discord.py, DCG Bot wasn't designed in a corporate boardroom. It was created by a solo developer who genuinely loves experimenting with code. Every command, every quirky interaction, and every hidden feature was handcrafted out of pure curiosity.
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* 4. Stats / Scale Section */}
      <section className="py-24 bg-card border-b border-white/5 relative z-10">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: "Total Commands", value: "60+", icon: Terminal, color: "text-primary" },
              { label: "Fun Factors", value: "Infinite", icon: Smile, color: "text-secondary" },
              { label: "Biscuits Baked", value: "Millions", icon: Coins, color: "text-accent" },
              { label: "Uptime", value: "99.9%", icon: Activity, color: "text-green-400" }
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-4">
                  <stat.icon className={`w-8 h-8 ${stat.color} opacity-80`} />
                </div>
                <div className={`text-4xl md:text-5xl font-black mb-2 text-white`}>{stat.value}</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Features Grid */}
      <section className="py-32 bg-background relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-1/2 h-full bg-gradient-to-r from-primary/5 to-transparent blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-1/2 h-full bg-gradient-to-l from-secondary/5 to-transparent blur-3xl pointer-events-none" />

        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-20"
          >
            <h2 className="text-4xl md:text-6xl font-black mb-6 text-white">Not Just Another Bot</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-light">Dozens of commands meticulously organized into powerful categories to keep your server active and entertained.</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Economy */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="p-10 rounded-3xl glass-panel bg-card/50 group hover:bg-card hover:border-primary/50 transition-all hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl group-hover:bg-primary/20 transition-colors" />
              <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform relative z-10 border border-primary/30">
                <Coins className="w-8 h-8 text-primary drop-shadow-[0_0_15px_hsl(var(--primary)/0.8)]" />
              </div>
              <h3 className="text-3xl font-black mb-4 tracking-tight text-white">Economy & Progression</h3>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed font-light">
                A full-fledged currency system powered by "Biscuits". Earn daily rewards, work jobs, commit crimes (virtually), steal from friends, and climb the leaderboard.
              </p>
              <div className="flex flex-wrap gap-2 relative z-10">
                {['/work', '/crime', '/steal', '/shop', '/openbox'].map(cmd => (
                  <span key={cmd} className="px-3 py-1.5 rounded-lg bg-background/80 border border-white/10 font-mono text-sm text-primary/90 font-medium shadow-sm">{cmd}</span>
                ))}
              </div>
            </motion.div>

            {/* Games */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="p-10 rounded-3xl glass-panel bg-card/50 group hover:bg-card hover:border-secondary/50 transition-all hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-secondary/10 rounded-full blur-3xl group-hover:bg-secondary/20 transition-colors" />
              <div className="w-16 h-16 bg-secondary/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform relative z-10 border border-secondary/30">
                <Gamepad2 className="w-8 h-8 text-secondary drop-shadow-[0_0_15px_hsl(var(--secondary)/0.8)]" />
              </div>
              <h3 className="text-3xl font-black mb-4 tracking-tight text-white">Games & Fun</h3>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed font-light">
                Endless entertainment to keep chat active. Test your luck, flip burgers, ask the 8-ball, discover your true brain cell count, or rate how silly your friends are.
              </p>
              <div className="flex flex-wrap gap-2 relative z-10">
                {['/burgerflip', '/8ball', '/braincellcount', '/ship', '/femboyrate'].map(cmd => (
                  <span key={cmd} className="px-3 py-1.5 rounded-lg bg-background/80 border border-white/10 font-mono text-sm text-secondary/90 font-medium shadow-sm">{cmd}</span>
                ))}
              </div>
            </motion.div>

            {/* Utility */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="p-10 rounded-3xl glass-panel bg-card/50 group hover:bg-card hover:border-accent/50 transition-all hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl group-hover:bg-accent/20 transition-colors" />
              <div className="w-16 h-16 bg-accent/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform relative z-10 border border-accent/30">
                <Wrench className="w-8 h-8 text-accent drop-shadow-[0_0_15px_hsl(var(--accent)/0.8)]" />
              </div>
              <h3 className="text-3xl font-black mb-4 tracking-tight text-white">Utility & Social</h3>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed font-light">
                Powerful tools for server management mixed with social features. From AFK tracking and server info to random facts, countdowns, and hex palettes.
              </p>
              <div className="flex flex-wrap gap-2 relative z-10">
                {['/afk', '/serverinfo', '/palette', '/catfact', '/countdown'].map(cmd => (
                  <span key={cmd} className="px-3 py-1.5 rounded-lg bg-background/80 border border-white/10 font-mono text-sm text-accent/90 font-medium shadow-sm">{cmd}</span>
                ))}
              </div>
            </motion.div>

            {/* Combat */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="p-10 rounded-3xl glass-panel bg-card/50 group hover:bg-card hover:border-destructive/50 transition-all hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-destructive/10 rounded-full blur-3xl group-hover:bg-destructive/20 transition-colors" />
              <div className="w-16 h-16 bg-destructive/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform relative z-10 border border-destructive/30">
                <ShieldAlert className="w-8 h-8 text-destructive drop-shadow-[0_0_15px_hsl(var(--destructive)/0.8)]" />
              </div>
              <h3 className="text-3xl font-black mb-4 tracking-tight text-white">Interactive Boss Fights</h3>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed font-light">
                Take the economy to the next level with server-wide combat events. Spawn bosses, coordinate attacks, and reap massive rewards if your server survives the encounter.
              </p>
              <div className="flex flex-wrap gap-2 relative z-10">
                {['/spawnboss', '/attack', '/biscuitsadmin', '/pick'].map(cmd => (
                  <span key={cmd} className="px-3 py-1.5 rounded-lg bg-background/80 border border-white/10 font-mono text-sm text-destructive/90 font-medium shadow-sm">{cmd}</span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 6. Terminal/Code Section */}
      <section className="py-32 bg-background border-y border-white/5 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-primary/5 blur-[200px] rounded-full pointer-events-none" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="order-2 lg:order-1"
            >
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#0A0A0E] shadow-[0_0_50px_rgba(0,0,0,0.8)] relative group">
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-destructive/80" />
                    <div className="w-3 h-3 rounded-full bg-chart-4" />
                    <div className="w-3 h-3 rounded-full bg-chart-5" />
                  </div>
                  <div className="text-xs text-white/40 font-mono flex items-center gap-2">
                    <Terminal className="w-3 h-3" />
                    bot.py
                  </div>
                </div>
                <div className="p-6 md:p-8 font-mono text-sm sm:text-base text-primary/80 overflow-x-auto leading-relaxed h-[400px]">
                  <p><span className="text-secondary">import</span> discord</p>
                  <p><span className="text-secondary">import</span> random</p>
                  <p><span className="text-secondary">from</span> discord.ext <span className="text-secondary">import</span> commands</p>
                  <br />
                  <p><span className="text-accent">@bot.tree.command</span>(name=<span className="text-chart-5">"work"</span>, description=<span className="text-chart-5">"Earn some biscuits"</span>)</p>
                  <p><span className="text-secondary">async def</span> <span className="text-blue-400">work</span>(interaction: discord.Interaction):</p>
                  <p className="pl-4 text-white/50"># Calculate random earnings</p>
                  <p className="pl-4">earnings = random.randint(<span className="text-chart-4">50</span>, <span className="text-chart-4">200</span>)</p>
                  <br />
                  <p className="pl-4 text-white/50"># Add to user balance in database</p>
                  <p className="pl-4">await economy.add_biscuits(interaction.user.id, earnings)</p>
                  <br />
                  <p className="pl-4 text-white/50"># Create a fancy embed</p>
                  <p className="pl-4">embed = discord.Embed(</p>
                  <p className="pl-8">title=<span className="text-chart-5">"Hard Work Pays Off!"</span>,</p>
                  <p className="pl-8">description=<span className="text-chart-5">f"You worked hard and earned **&#123;earnings&#125;** biscuits!"</span>,</p>
                  <p className="pl-8">color=discord.Color.gold()</p>
                  <p className="pl-4">)</p>
                  <br />
                  <p className="pl-4 text-white/50"># Send the response</p>
                  <p className="pl-4">await interaction.response.send_message(embed=embed)</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#0A0A0E] to-transparent pointer-events-none" />
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="order-1 lg:order-2"
            >
              <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-2xl mb-8 border border-primary/20 box-glow">
                <Cpu className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-6 tracking-tight text-white">Modern Architecture</h2>
              <p className="text-xl text-muted-foreground mb-10 leading-relaxed font-light">
                Powered by the robust discord.py library, DCG Bot utilizes slash commands, interactive buttons, and real-time modals for a seamless user experience. No more typing clunky prefixes.
              </p>
              
              <ul className="space-y-6">
                {[
                  { title: "Lightning fast responses", desc: "Built with modern async Python", icon: <Zap className="w-5 h-5 text-primary" /> },
                  { title: "Interactive UI", desc: "Buttons, dropdowns, and modals", icon: <Hash className="w-5 h-5 text-secondary" /> },
                  { title: "Slash commands native", desc: "Fully integrated with Discord's UI", icon: <Code2 className="w-5 h-5 text-accent" /> }
                ].map((item, i) => (
                  <motion.li 
                    key={i} 
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 + (i * 0.1) }}
                    className="flex items-start gap-4 group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0 mt-1 group-hover:bg-white/10 transition-colors">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-white">{item.title}</h4>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 7. CTA Section */}
      <section className="py-40 relative overflow-hidden flex items-center justify-center text-center bg-card">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-primary/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/20 blur-[150px] rounded-full pointer-events-none" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, type: "spring" }}
            className="max-w-4xl mx-auto"
          >
            <div className="mb-10 inline-flex items-center justify-center p-6 bg-background rounded-full border border-white/10 shadow-2xl relative">
              <div className="absolute inset-0 rounded-full box-glow animate-pulse" />
              <Bot className="w-16 h-16 text-primary relative z-10" />
            </div>
            
            <h2 className="text-5xl md:text-8xl font-black mb-8 text-glow tracking-tighter text-white">Ready for Chaos?</h2>
            <p className="text-2xl md:text-3xl text-muted-foreground mb-12 font-light">
              Join the servers already enjoying the economy, games, and absolute randomness of DCG Bot.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <a href={INVITE_URL} target="_blank" rel="noopener noreferrer" data-testid="footer-invite-btn">
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto rounded-full px-12 h-20 text-2xl font-black bg-primary text-white hover:bg-primary/90 shadow-[0_0_50px_hsl(var(--primary)/0.5)] transition-all hover:scale-105 hover:-translate-y-2 group"
                >
                  <SiDiscord className="w-8 h-8 mr-4" />
                  Add to Discord
                  <ArrowRight className="w-8 h-8 ml-4 group-hover:translate-x-2 transition-transform" />
                </Button>
              </a>
            </div>
            
            <p className="mt-10 text-sm text-muted-foreground font-mono">
              Requires 'Send Messages' and 'Use Slash Commands' permissions
            </p>
          </motion.div>
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="py-12 border-t border-white/10 bg-background relative z-10">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center border border-primary/30">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <span className="font-sans font-bold tracking-tight text-white">DCG Bot</span>
          </div>
          <p className="text-sm text-muted-foreground font-light text-center md:text-left">
            A passion project built with Python, discord.py, and probably too much caffeine.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">Terms</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">Privacy</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium flex items-center gap-2">
              <SiDiscord className="w-4 h-4" />
              Support
            </a>
          </div>
        </div>
      </footer>

      {/* Global styles for floating animation */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes float {
          0% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(2deg); }
          100% { transform: translateY(0px) rotate(0deg); }
        }
      `}} />
    </div>
  );
}
